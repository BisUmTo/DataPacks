﻿               •• RedCraft2 2018 ••
			  • Powered by BisUmTo •
         • http://youtube.com/BisUmTo •
		
			   • Versione: 2.1.2 •

      • Come installare questo DataPack •
Per avviare il predente DataPack, basta semplicemente inserire questo file .zip all'interno della cartella datapacks del mondo desiderato ed eseguire il comando /reload all'interno del gioco.

			      • Features •
L'elenco di tutte le features lo puoi trovare su https://bisumto.it/redcraft2
